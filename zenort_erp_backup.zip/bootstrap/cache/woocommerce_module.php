<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Woocommerce\\Providers\\WoocommerceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Woocommerce\\Providers\\WoocommerceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);